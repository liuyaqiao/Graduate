make to compile all the .cc files!
./main size (./main 100) to run the program q1 and ./main to run the program q3!
make clean to clean the .o .exe files!



Thank you for attention on my homework!!!
